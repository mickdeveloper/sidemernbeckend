const mongoose=require('mongoose')
const validator=require('validator')

const ClientsSchema=mongoose.Schema({
    name:{
        type:String,
        required:true,
        
    },
   
    email:{
        type:String,
        required:true,
        validate(value){
            if(!validator.isEmail(value)){
                throw new Error ('Not valid email address!')
            }
        }

    },
    phone:
    {
        type:Number,
        required:true,
        maxlength:10
    },
   
    sub:{
        type:String,
        required:true,
        
    },
   
    address:{
        type:String,
        required:true,
        
    },
    msg:{
        type:String,
        required:true,
    },
   
   
    timestamp: { type: String, default: new Date()},
   
   
    
})

module.exports=mongoose.model('Client', ClientsSchema)