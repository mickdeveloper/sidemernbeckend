const mongoose=require('mongoose')


const adminproductSchema=mongoose.Schema({
    productname:String,
    productlink:String,
    image:String,
    status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('adminproducts', adminproductSchema)