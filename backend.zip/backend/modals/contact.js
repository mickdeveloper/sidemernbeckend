const mongoose=require('mongoose')


const bintechcontactschema=mongoose.Schema({
    address:String,
    link_fb:String,
    link_insta:String,
    link_linkedln:String,
    lk_twt:String,
    phone:Number,
    officeemail:String,
   status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('contactdetails', bintechcontactschema)