const mongoose=require('mongoose')


const adminserviceSchema=mongoose.Schema({
    image:String,
    sname:String,
    desc:String,
    
    status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('adminservice', adminserviceSchema)