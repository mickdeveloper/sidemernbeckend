const mongoose=require('mongoose')


const cappySchema=mongoose.Schema({
    name:{
        type:String,
         },
   
    email:{
        type:String,
        required:true,},
    phone:
    {
        type:Number,
        required:true,
        maxlength:10
    },
   
    applyfor:{
        type:String,
        required:true,
        
    },
   
    image:{
        type:String,
        required:true,
        
    },

    exp:{
        type:String,
        required:true,
    },
 
    timestamp: { type: String, default: new Date()},
   
   
    
})

module.exports=mongoose.model('Appliedjob', cappySchema)