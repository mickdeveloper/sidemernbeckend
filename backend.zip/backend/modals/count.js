const mongoose=require('mongoose')


const countschema=mongoose.Schema({
    Launched:String,
    yearexp:String,
    developers:String,
    client:String,
   status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('count', countschema)