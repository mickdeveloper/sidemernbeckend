const mongoose=require('mongoose')


const TeamsSchema=mongoose.Schema({
    image:String,
    Empname:String,
    Emp_posstion:String,
    status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('Teamdeatils',TeamsSchema)