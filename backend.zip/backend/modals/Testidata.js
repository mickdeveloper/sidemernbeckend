const mongoose=require('mongoose')


const TestiSchema=mongoose.Schema({
    image:String,
    Tname:String,
    Tposstion:String,
    Tabout:String,
    status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('Testidata',TestiSchema)