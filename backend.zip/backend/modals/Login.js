const mongoose=require('mongoose')
const validator=require('validator')



const admin_login=mongoose.Schema({
    email:{
        type:String,
        required:true,
        validate(value){
            if(!validator.isEmail(value)){
                throw new Error ('Not valid email address!')
            }
        }

    },
    pass:{
        type:String,
        required:true,
        minilength:6
    }
})
module.exports=mongoose.model('adminlogin', admin_login)