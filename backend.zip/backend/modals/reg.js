const mongoose=require('mongoose')
const validator=require('validator')



const admin_signin=mongoose.Schema({
    email:{
        type:String,
        required:true,
        validate(value){
            if(!validator.isEmail(value)){
                throw new Error ('Not valid email address!')
            }
        }

    },
    pass:{
        type:String,
        required:true,
        minilength:6
    },
    // token:[
    //     {
    //         token:{
    //             type:String,
    //             required:true
    //         }
    //     }
    // ],
    // carts:Array
    // email:String,
    // pass:String,

})
module.exports=mongoose.model('reg', admin_signin)