const mongoose=require('mongoose')


const ClogoSchema=mongoose.Schema({
    
    image:String,
    status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('Clogo', ClogoSchema)