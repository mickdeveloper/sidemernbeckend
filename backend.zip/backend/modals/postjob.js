const mongoose=require('mongoose')


const adminjobpostSchema=mongoose.Schema({
    title:String,
    vacancies:Number,
    workstatus:String,
    exp :String,
    Location:String,
   status:{type:String,default:'Inactive'}
})

module.exports=mongoose.model('postjob', adminjobpostSchema)