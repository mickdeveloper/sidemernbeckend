const productadd=require('../modals/adminproducts')

exports.addprod=(req,res)=>{
    const {productname,productlink}=req.body
    //console.log(req.body)
    //console.log(req.file)
    try{
      if(req.file){
          const filename= req.file.filename
          const record= new productadd({ image:filename,productname:productname, productlink:productlink})
      record.save()
      res.json({
          status:200,
          message:'Product add successfully.',
          apiData:record,
      })
  
      }else{
          const record= new productadd({productname:productname, productlink:productlink})
          record.save()
          res.json({
              status:200,
              message:'Product add successfully.',
              apiData:record,
          })
  
      }
      
    }catch(error){
      res.json({
          status:500,
          message:'Internal server error',
          
      })
  
    }
  }

exports.showallproducts=async(req,res)=>{
    try{
        const record=await productadd.find()
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            
            message:"interal error"
        })

    }
}

exports.productdelete=async(req,res)=>{
    const id=(req.params.id)
 try{
     await productadd.findByIdAndDelete(id)
     res.json({
        status:200,
         message:"successfully Deleted"
     })
 
  }catch(error){
   res.json({message:error.message})  
  }
  }
  exports.singlepdtdata=async(req,res)=>{
    const id=req.params.id
    try{
        const record=await productadd.findById(id)
        res.json({
            status:200,
            apiData:record,
            message:'suceess'
        })

    }catch(error){
        res.json({
            status:500,
            message:'server error'
        })

    }
   
   

}
exports.singlepdtupate=async(req,res)=>{
    const id=req.params.id
    // console.log(req.params.id)
    // console.log(req.body)
    // console.log(req.file)
         const {productname,productlink,st}=req.body
        try{
            if(req.file){
                const filename= req.file.filename
                const record=await productadd.findByIdAndUpdate(id,{image:filename, productname:productname,productlink:productlink,status:st})
                res.json({
                   status:200,
                   message:" successfully Update",
                   apiData:record
                })
            }else{
                const record=await productadd.findByIdAndUpdate(id,{productname:productname,productlink:productlink,status:st})
                res.json({
                   status:200,
                   message:" successfully Update",
                   apiData:record
                })

            }
            
        }catch(error){
            res.json({
                status:500,
                message:"error"
            })
           

        }
}

exports.userpdtshowdata=async(req,res)=>{
    try{
      const record = await productadd.find({status:'Active'})
      res.json({
          status:200,
          apiData:record,
          message:'success'
      })
    }catch(error){
      res.json({
          status:500,
        
          message:'server error'
      })
  
    }
   }
 