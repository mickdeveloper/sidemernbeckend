const AdminService=require('../modals/adminservice')

exports.serviceadd= async(req,res)=>{
    const {text,sname}=req.body
     //console.log(req.body)
    // console.log(req.file)
try{
   
          if(req.file){
      const filename= req.file.filename
      
       const record = await  new AdminService ({image:filename,desc:text,sname:sname})
       record.save()
       res.json({
        status:200,
        message:'successfully.',
        apiData:record
    })
    }else{
        const record = await new AdminService ({desc:text,sname:sname})
        record.save()
        res.json({
            status:200,
            message:'successfully.',
            apiData:record
        })
     }
    

}catch(error){
    res.json({
        status:500,
        message:'error.',
        
    })

}

   
}

exports.showAllservice=async(req,res)=>{
    try{
        const record=await AdminService.find()
       // console.log(record)
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            message:"interal error"
        })

    }
}

exports.singleservicetdata=async(req,res)=>{
    const id=req.params.id
    // console.log(req.params.id)

    try{
        const record=await AdminService.findById(id)
        res.json({
            status:200,
            apiData:record,
            message:'suceess'
        })

    }catch(error){
        res.json({
            status:500,
            message:'server error'
        })
    }

    }
 exports.serviceupdate=async(req,res)=>{
        const  id = req.params.id
          // console.log(req.body)
        //console.log(req.file)
       const {desc,st,sname}= req.body
       
       try{
          
           if(req.file){
       
                const filename= req.file.filename
        const record = await  AdminService.findByIdAndUpdate(id,{image:filename,desc:desc, status:st,sname:sname})
        record.save()
        res.json({
         status:200,
         message:'successfully.',
         apiData:record
       })
       }else{
         const record = await AdminService.findByIdAndUpdate(id, {desc:desc, link:link,status:st,sname:sname})
         record.save()
         res.json({
             status:200,
             message:'successfully.',
             apiData:record
         })
       }
       
       
       }catch(error){
       res.json({
         status:500,
         message:'error.',
         
       })}
       }     


exports.servicedelete=async(req,res)=>{
     const id=req.params.id
  try{
      await AdminService.findByIdAndDelete(id)
      res.json({
          status:200,
          message:"successfully Deleted"
      })
  
   }catch(error){
    res.json({message:error.message})  
   }
   }

exports.usershowservice=async(req,res)=>{
    try{
      const record = await AdminService.find({status:'Active'})
      res.json({
          status:200,
          apiData:record,
          message:'success'
      })
    }catch(error){
      res.json({
          status:500,
        
          message:'server error'
      })
  
    }
   }   