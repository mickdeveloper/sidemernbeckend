const Login=require('../modals/reg')
const nodemailer= require('nodemailer')


exports.login_admin=async(req,res)=>{
    const {email,password}=req.body
    try{
        const usercheck= await  Login.findOne({email:email, pass:password})
        if(usercheck!==null){
           if(usercheck.pass==password){
            res.json({
                status:200,
                apidata: usercheck,
                message:"Successfully Login"
                
            })
           }
           else{
        res.json({
            status:400,
            message:"Worng Credentails*"
        })
       }
     } else{
           res.json({
               status:400,
               message:"Worng Credentails*"
           })
       }
    }
  catch(error){
    res.json({
        status:500,
        message:"Server error"
    })

}
}

exports.forgotlink=async(req,res)=>{
    console.log(req.body)
    
      const {email}=req.body;
      if(!email){
        res.status(401).json({status:401,message:"Email does not exit! "})
      }
      try{
        const userfind= await Login.findOne({email:email})
if(userfind.email!==''){
  
    const mailcheck=userfind.email
    // smtp seerver confi.
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user: "sharewithcoder@gmail.com",
          pass: "zzxm hkdk jvso tzdi",
        },
      });

      console.log("yeah that's great thinks that your server is connneted")
        const info = await transporter.sendMail({
          from: "Brixcode👻'sharewithcoder@gmail.com'", // sender address
          to: 'info@brixcodetechnologies.com', // list of receivers
          subject: "Forgot link ", // Subject line
          text: "Pls click here to change password and make sure that link will actived only 5 min ", // plain text body
          html: `<a href=http://localhost:3000/newpass/${email}> forgot password?click here to change password</a>`
          // html body
        });
        console.log("sent your mail pls check mail & spum also")
        res.status(200).json({status:200,message:"A link sent your Registered mail id pls check"})
}
else{
  res.status(400).json({status:400,message:"Entered mail is worng! kindly cheked your mail"})
}
        
      }catch(error){
        
        console.log('error');
        message:"somthing went wrong try again!"
            
      }
  }

  exports.newpasslink=async(req,res)=>{
    //console.log(req.params.user_email)
    
    
    const username= req.params.user_email
    // console.log(username)

     try{
       const record= await Login.find({email:username})
       //console.log(record)
       res.json({
          status:200,
          apiData:record,
        message:'suceess'
     })

   }catch(error){
      res.json({
          status:500,
          message:'server error'
      })
  }
}  
exports.newpasswordupdate=async(req,res)=>{
    // console.log(req.params.user_email)
    //  console.log(req.body)
    const username= req.params.user_email
    const {pass}= req.body
    try{
      const record=await Login.findOneAndUpdate({pass:pass})
      console.log(record)
      res.json({
        status:200,
        message:" successfully Update",
        apiData:record
     })
    }catch(error){
      res.json({
        status:500,
        message:"error",
       
     })
  
    }
  }


