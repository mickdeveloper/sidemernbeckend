const  Bintechcontact=require('../modals/contact')


exports.showcdts=async(req,res)=>{
    
    try{
        const record=await Bintechcontact.find()
       
       // console.log(record)
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            message:"interal error"
        })

   }
}

exports.singlecd= async(req,res)=>{
    const id=req.params.id
    try{
        const record=await Bintechcontact.findById(id)
        res.json({
            status:200,
            apiData:record,
            message:'suceess'
        })

    }catch(error){
        res.json({
            status:500,
            message:'server error'
        })

    }
} 

exports.cdtup=async(req,res)=>{
    const id=req.params.id
    const {officeemail,st,phone,link_fb,link_insta,link_linkedln,address,lk_twt}=req.body
    try{
         const record=await Bintechcontact.findByIdAndUpdate(id,{
            officeemail:officeemail,status:st,phone:phone,link_fb:link_fb,link_insta:link_insta,link_linkedln:link_linkedln,address:address,lk_twt:lk_twt})
         res.json({
            status:200,
            message:" successfully Update",
            apiData:record
         })
    }catch(error){
        res.json({
            status:500,
            message:"error"
        })
       

    }

}


exports.usershowcdt=async(req,res)=>{
    try{
      const record = await Bintechcontact.find({status:'Active'})
      res.json({
          status:200,
          apiData:record,
          message:'success'
      })
    }catch(error){
      res.json({
          status:500,
        
          message:'server error'
      })
  
    }
   }     