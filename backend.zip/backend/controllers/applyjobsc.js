const  Applyjob=require('../modals/Appliedjob')



exports.jobsapplydata=async(req,res)=>{
    // console.log(req.body)
    // console.log(req.file)
    const {cname,cemail,capply,cphone,cexp}=req.body
    try{
   if(req.file){
   const filename= req.file.filename
   
    const record = await  new Applyjob ({image:filename,name:cname,email:cemail,applyfor:capply,exp:cexp,phone:cphone})
    record.save()
    res.json({
     status:200,
     message:'successfully.',
     apiData:record
 })
 }else{
     const record = await new Applyjob ({name:cname,email:cemail,applyfor:capply,exp:cexp,phone:cphone})
    record.save()
     res.json({
         status:200,
         message:'successfully.',
         apiData:record
     })
  }
 

}catch(error){
 res.json({
     status:500,
     message:'error.',
     
 })

}
   
}

exports.showalljobapplication=async(req,res)=>{
     try{
         const record=await Applyjob.find().sort({timestamp:-1})
        
         res.json({
             status:200,
             apiData:record,
             message:"success slection"
         })
 
     }catch(error){
         res.json({
             status:500,
             message:"interal error"
         })
 
    }
 }

exports.removejobapplications=async(req,res)=>{
    const id=req.params.id
  try{
      await Applyjob.findByIdAndDelete(id)
      res.json({
          status:200,
          message:"successfully Deleted"
      })
  
   }catch(error){
    res.json({message:error.message})  
   }
} 