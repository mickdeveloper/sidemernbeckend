const Count=require('../modals/count')

exports.addcounter=(req,res)=>{
    const {Launched,yearexp,developers,client}=req.body
  try{
    const record= new Count({Launched:Launched,yearexp:yearexp,developers:developers,client:client})
    record.save()
    res.json({
        status:200,
        message:'Jobpost add successfully.',
        apiData:record,
    })

  }catch(error){
    res.json({
        status:500,
        message:'Internal server error',
        
    })

  }
}

exports.showcount= async(req,res)=>{
    try{
        const record=await Count.find()
          
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            
            message:"interal error"
        })

    }
}


exports.usercount=async(req,res)=>{
    try{
      const record = await Count.find({status:'Active'})
      res.json({
          status:200,
          apiData:record,
          message:'success'
      })
    }catch(error){
      res.json({
          status:500,
        
          message:'server error'
      })
  
    }
   } 
   
exports.singlecount= async(req,res)=>{
    const id=req.params.id
    try{
        const record=await Count.findById(id)
        res.json({
            status:200,
            apiData:record,
            message:'suceess'
        })

    }catch(error){
        res.json({
            status:500,
            message:'server error'
        })

    }
} 

exports.singleupdatecount=async(req,res)=>{
    const id=req.params.id
    const {Launched,yearexp,developers,client,st}=req.body
    try{
         const record=await Count.findByIdAndUpdate(id,{
            Launched:Launched,yearexp:yearexp,developers:developers,client:client,status:st})
         res.json({
            status:200,
            message:" successfully Update",
            apiData:record
         })
    }catch(error){
        res.json({
            status:500,
            message:"error"
        })
       

    }

}
