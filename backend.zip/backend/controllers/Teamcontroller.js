const Team=require('../modals/Teamdeatils')


exports.teamdataadd= async(req,res)=>{
    const {empname,empposition}=req.body
     //console.log(req.body)
    // console.log(req.file)
try{
   
          if(req.file){
      const filename= req.file.filename
      
       const record = await  new Team ({image:filename,Empname:empname,Emp_posstion:empposition})
       record.save()
       res.json({
        status:200,
        message:'successfully.',
        apiData:record
    })
    }else{
        const record = await new Team ({Empname:empname,Emp_posstion:empposition})
        record.save()
        res.json({
            status:200,
            message:'successfully.',
            apiData:record
        })
     }
    

}catch(error){
    res.json({
        status:500,
        message:'error.',
        
    })

}

   
}

exports.showteams=async(req,res)=>{
    try{
        const record=await Team.find()
       // console.log(record)
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            message:"interal error"
        })

    }
}

exports.teamempdelete=async(req,res)=>{
    const id=req.params.id
 try{
     await Team.findByIdAndDelete(id)
     res.json({
         status:200,
         message:"successfully Deleted"
     })
 
  }catch(error){
   res.json({message:error.message})  
  }
  }

  exports.singleteamdata=async(req,res)=>{
    const id=req.params.id
    // console.log(req.params.id)

    try{
        const record=await Team.findById(id)
        res.json({
            status:200,
            apiData:record,
            message:'suceess'
        })

    }catch(error){
        res.json({
            status:500,
            message:'server error'
        })
    }

    }  

 exports.teamsupdate=async(req,res)=>{
        const  id = req.params.id
          // console.log(req.body)
        //console.log(req.file)
       const {empname,empposition,st}= req.body
       
       try{
          
           if(req.file){
       
                const filename= req.file.filename
        const record = await  Team.findByIdAndUpdate(id,{image:filename,Empname:empname,Emp_posstion:empposition,status:st})
        record.save()
        res.json({
         status:200,
         message:'successfully.',
         apiData:record
       })
       }else{
         const record = await Team.findByIdAndUpdate(id, {Empname:empname,Emp_posstion:empposition,status:st})
         record.save()
         res.json({
             status:200,
             message:'successfully.',
             apiData:record
         })
       }
       
       
       }catch(error){
       res.json({
         status:500,
         message:'error.',
         
       })}
       }  
       
exports.showteamonfront=async(req,res)=>{
        try{
          const record = await Team.find({status:'Active'})
          res.json({
              status:200,
              apiData:record,
              message:'success'
          })
        }catch(error){
          res.json({
              status:500,
            
              message:'server error'
          })
      
        }
       }        
