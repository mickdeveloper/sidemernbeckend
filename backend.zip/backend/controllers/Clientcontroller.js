const Client=require('../modals/client')


exports.Clientreqst=(req,res)=>{
 const {name,address,msg,email,phone,sub}=req.body
 try{
    const record= new Client({name:name,address:address,msg:msg,email:email,phone:phone,sub:sub})
    record.save()
    res.json({
        status:200,
        message:'Clinent add successfully.',
        apiData:record,
    })


 }catch(error){
    res.json({
        status:500,
        message:'error.',
       
    })

 }

}

exports.showleads=async(req,res)=>{
    try{
        const record=await Client.find().sort({timestamp:-1})
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            
            message:"interal error"
        })

    }
}

exports.leadsdelete=async(req,res)=>{
    const id=(req.params.id)
 try{
     await Client.findByIdAndDelete(id)
     res.json({
        status:200,
         message:"successfully Deleted"
     })
 
  }catch(error){
   res.json({message:error.message})  
  }
  }