const CLogo=require('../modals/Clogo')



exports.clogoadd=async(req,res)=>{
    //console.log(req.file)

    try{
        const filename= req.file.filename
        
         const record = await  new CLogo ({image:filename})
         record.save()
         res.json({
          status:200,
          message:'successfully.',
          apiData:record
      })
    }catch(error){
        res.json({
            status:500,
            message:'error',
      })

    }
}

exports.showlogofromdb=async(req,res)=>{
    try{
        const record=await CLogo.find()
       //console.log(record)
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            message:"interal error"
        })

    }
}

exports.logodelete=async(req,res)=>{
    const id=(req.params.id)
 try{
     await CLogo.findByIdAndDelete(id)
     res.json({
        status:200,
         message:"successfully Deleted"
     })
 
  }catch(error){
   res.json({message:error.message})  
  }
  }

  exports.showlogostouser=async(req,res)=>{
    try{
        const record = await CLogo.find({status:'Inactive'})
        res.json({
            status:200,
            apiData:record,
            message:'success'
        })
      }catch(error){
        res.json({
            status:500,
          
            message:'server error'
        })
    
      }
}  