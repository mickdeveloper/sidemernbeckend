const Testi=require('../modals/Testidata')


exports.testidataadd= async(req,res)=>{
    const {empname,empposition,tabout}=req.body
     //console.log(req.body)
    // console.log(req.file)
try{
   
          if(req.file){
      const filename= req.file.filename
      
       const record = await  new Testi ({image:filename,Tname:empname,Tposstion:empposition,Tabout:tabout})
       record.save()
       res.json({
        status:200,
        message:'successfully.',
        apiData:record
    })
    }else{
        const record = await new Testi ({Tname:empname,Tposstion:empposition,Tabout:tabout})
        record.save()
        res.json({
            status:200,
            message:'successfully.',
            apiData:record
        })
     }
    

}catch(error){
    res.json({
        status:500,
        message:'error.',
        
    })

}

   
}


exports.showtestiontable=async(req,res)=>{
    try{
        const record=await Testi.find()
       // console.log(record)
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            message:"interal error"
        })

    }
}

exports.singletestidata=async(req,res)=>{
    const id=req.params.id
    // console.log(req.params.id)

    try{
        const record=await Testi.findById(id)
        res.json({
            status:200,
            apiData:record,
            message:'suceess'
        })

    }catch(error){
        res.json({
            status:500,
            message:'server error'
        })
    }

    }  


exports.testiupdate=async(req,res)=>{
        const  id = req.params.id
          // console.log(req.body)
        //console.log(req.file)
       const {empname,empposition,st,tabout}= req.body
       
       try{
          
           if(req.file){
       
                const filename= req.file.filename
        const record = await  Testi.findByIdAndUpdate(id,{image:filename,Tname:empname,Tposstion:empposition,Tabout:tabout,status:st})
        record.save()
        res.json({
         status:200,
         message:'successfully.',
         apiData:record
       })
       }else{
         const record = await Testi.findByIdAndUpdate(id, {status:st,Tname:empname,Tposstion:empposition,Tabout:tabout})
         record.save()
         res.json({
             status:200,
             message:'successfully.',
             apiData:record
         })
       }
       
       
       }catch(error){
       res.json({
         status:500,
         message:'error.',
         
       })}
       } 

exports.testidelete=async(req,res)=>{
    const id=req.params.id
 try{
     await Testi.findByIdAndDelete(id)
     res.json({
         status:200,
         message:"successfully Deleted"
     })
 
  }catch(error){
   res.json({message:error.message})  
  }
  }

exports.showtestionfront=async(req,res)=>{
    try{
      const record = await Testi.find({status:'Active'})
      res.json({
          status:200,
          apiData:record,
          message:'success'
      })
    }catch(error){
      res.json({
          status:500,
        
          message:'server error'
      })
  
    }
   }    