const Adminjob=require('../modals/postjob')

exports.addjobpost=(req,res)=>{
    const {vacancies,workstatus,exp,title,location}=req.body
  try{
    const record= new Adminjob({title:title,vacancies:vacancies,exp:exp,Location:location, workstatus:workstatus})
    record.save()
    res.json({
        status:200,
        message:'Jobpost add successfully.',
        apiData:record,
    })

  }catch(error){
    res.json({
        status:500,
        message:'Internal server error',
        
    })

  }
}

exports.showjobs= async(req,res)=>{
    try{
        const record=await Adminjob.find()
          
        res.json({
            status:200,
            apiData:record,
            message:"success slection"
        })

    }catch(error){
        res.json({
            status:500,
            
            message:"interal error"
        })

    }
}

exports.singlejobsdata= async(req,res)=>{
    const id=req.params.id
    try{
        const record=await Adminjob.findById(id)
        res.json({
            status:200,
            apiData:record,
            message:'suceess'
        })

    }catch(error){
        res.json({
            status:500,
            message:'server error'
        })

    }
}
exports.singleupdatedata=async(req,res)=>{
    const id=req.params.id
    const {title,vacancies,exp,workstatus,status,Location}=req.body
    try{
         const record=await Adminjob.findByIdAndUpdate(id,{
            title:title,exp:exp,vacancies:vacancies,workstatus:workstatus,Location:Location,status:status})
         res.json({
            status:200,
            message:" successfully Update",
            apiData:record
         })
    }catch(error){
        res.json({
            status:500,
            message:"error"
        })
       

    }

}

exports.jobsdatadelete=async(req,res)=>{
    const id=(req.params.id)
 try{
     await Adminjob.findByIdAndDelete(id)
     res.json({
        status:200,
         message:"successfully Deleted"
     })
 
  }catch(error){
   res.json({message:error.message})  
  }
  }

  exports.usershowpostjobs=async(req,res)=>{
    try{
      const record = await Adminjob.find({status:'Active'})
      res.json({
          status:200,
          apiData:record,
          message:'success'
      })
    }catch(error){
      res.json({
          status:500,
        
          message:'server error'
      })
  
    }
   }     