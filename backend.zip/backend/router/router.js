const router=require('express').Router()
// const loginc=require('../controllers/logincontroller')
const signc=require('../controllers/logincontroller')
const Adminservicec=require('../controllers/adminservicecontroller')
const adminprodc=require('../controllers/adminpdtcontroller')
const jobpostc=require('../controllers/postjobcontroller')
const BintechC=require('../controllers/contactdtc')
const  Clientc = require('../controllers/Clientcontroller')
const Applyc=require('../controllers/applyjobsc')
const Teamc=require('../controllers/Teamcontroller')
const Testic=require('../controllers/Testicontroller')
const Logoc=require('../controllers/logocontrolloer')
const Countc=require('../controllers/countcontroller')



const multer=require('multer')
// const path =require('path')

let storage=multer.diskStorage({
    destination: function(req,file,cb){
          cb(null,'./public/upload')
       },
       filename: function(req,file,cb){
              cb(null,Date.now()+(file.originalname))
      } })
   
   let upload=multer({
      storage:storage,
    limits:{fileSize:1024*1024*5},
    fileFilter: (req, file, cb) => {
     if (file.mimetype === "application/pdf" || file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg" )
      
      {
        cb(null, true);
       } else {
       cb(null, false);
         return cb(new Error('Only .png, .jpg  .jpeg and pdf format allowed!'));
       }
     }

    })
//count config
router.post('/addcounter',Countc.addcounter)
router.get('/showcounterfromdb',Countc.showcount)
router.get('/usercountshow',Countc.usercount)
router.get('/singlecount/:id',Countc.singlecount)
router.put('/coutupdate/:id',Countc.singleupdatecount)


// client logo

router.post('/addlogo',upload.single('image'),Logoc.clogoadd)
router.get('/showlogosfromdb',Logoc.showlogofromdb)
router.delete('/logodelete/:id',Logoc.logodelete)
router.get('/usershowclogo',Logoc.showlogostouser)

//Testi config
router.post('/addtesti',upload.single('image'),Testic.testidataadd)
router.get('/showtesti',Testic.showtestiontable)
router.delete('/testidel/:id',Testic.testidelete)
router.get('/singledataoftesti/:id',Testic.singletestidata)
router.put('/testiupdate/:id',upload.single('image'),Testic.testiupdate)
router.get('/usershowtesti',Testic.showtestionfront)


//Teams config.
router.post('/addteam',upload.single('image'),Teamc.teamdataadd)
router.get('/showteams',Teamc.showteams)
router.delete('/teamdel/:id',Teamc.teamempdelete)
router.get('/singledataofteams/:id',Teamc.singleteamdata)
router.put('/teamupdate/:id',upload.single('image'),Teamc.teamsupdate)
router.get('/usershowteams',Teamc.showteamonfront)

//service config.
router.post('/addSimg',upload.single('image'),Adminservicec.serviceadd)
router.get('/showservices',Adminservicec.showAllservice)
router.delete('/adminservicedel/:id',Adminservicec.servicedelete)
router.get('/singledataofservice/:id',Adminservicec.singleservicetdata)
router.put('/servicetupdate/:id',upload.single('image'),Adminservicec.serviceupdate)
router.get('/userserviceshow',Adminservicec.usershowservice)


//product config
router.post('/addpd',upload.single('image'),adminprodc.addprod)
router.get('/showproducts',adminprodc.showallproducts)
router.get('/singlepddata/:id',adminprodc.singlepdtdata)
router.put('/productupdate/:id',upload.single('image'),adminprodc.singlepdtupate)
router.delete('/adminpoddelete/:id',adminprodc.productdelete)
router.get('/userpdtshow',adminprodc.userpdtshowdata)


//jobpost config
router.post('/addjobpost',jobpostc.addjobpost)
router.get('/showjobs',jobpostc.showjobs)
router.get('/singledataofjobs/:id',jobpostc.singlejobsdata)
router.put('/jobsupdatedata/:id',jobpostc.singleupdatedata)
router.delete('/jobsdatadelete/:id',jobpostc.jobsdatadelete)
router.get('/careershow',jobpostc.usershowpostjobs)

//job application congif
router.post('/applications',upload.single('resume'),Applyc.jobsapplydata)
router.get('/showapplications',Applyc.showalljobapplication)
router.delete('/deljobapplications/:id',Applyc.removejobapplications)

//contact Deatils config
router.get('/showcontactdeatils',BintechC.showcdts)
router.get('/single/:id',BintechC.singlecd)
router.put('/linksupdate/:id',BintechC.cdtup)
router.get('/showcdttofront',BintechC.usershowcdt)



//client request config
router.post('/clientrequest',Clientc.Clientreqst)
router.get('/showleads',Clientc.showleads)
router.delete('/leadsdel/:id',Clientc.leadsdelete)




router.post('/login',signc.login_admin)
router.post('/forgot_password_link',signc.forgotlink)
router.get('/new_pass_link/:user_email',signc.newpasslink)
 router.post('/newpass_update/:user_email',signc.newpasswordupdate)
// router.get('/getlogin',signc.getss)


module.exports=router;