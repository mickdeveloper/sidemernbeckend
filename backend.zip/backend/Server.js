const express=require('express')

const app =express();
require('dotenv').config()
const Adminrouter=require('./router/router')
const mongoose=require('mongoose')
//  const DB=process.env.DATABASE;
mongoose.connect(`${process.env.DB_URl}/${process.env.DB_NAME}`).then(()=>
    console.log('Databse is connected')
).catch((error)=>console.log('error db is not connected'))
const cors=require('cors')

app.use(express.static('public'))
app.use(express.json())
app.use('/brixapi',Adminrouter)
app.use(cors())
app.listen(process.env.PORT,function(){
console.log(`Yeah!! server is running 😍 on ${process.env.PORT}`);
})